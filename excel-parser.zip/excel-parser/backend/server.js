﻿const express = require("express");
const multer = require("multer");
const xlsx = require("xlsx");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = 3000;

// ===== НАСТРОЙКА =====
// Папка для временных файлов
const uploadDir = "uploads";
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// Настройка загрузки файлов
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + "-" + file.originalname;
    cb(null, uniqueName);
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const filetypes = /xls|xlsx|csv/;
    const ext = path.extname(file.originalname).toLowerCase();
    if (filetypes.test(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Только Excel/CSV файлы (.xls, .xlsx, .csv)"));
    }
  }
});

// ===== МАРШРУТЫ API =====

// 1. Проверка работы API
app.get("/api/health", (req, res) => {
  console.log("✅ Health check вызван");
  res.json({ 
    status: "OK", 
    message: "Excel Parser API работает",
    time: new Date().toISOString()
  });
});

// 2. ГЛАВНЫЙ ЭНДПОИНТ - обработка Excel файлов
app.post("/api/recognize-table", upload.single("file"), (req, res) => {
  console.log("=".repeat(50));
  console.log("📥 ЗАПРОС НА ОБРАБОТКУ ФАЙЛА");
  console.log("Файл:", req.file?.originalname || "Нет файла");
  
  try {
    // Проверяем, что файл загружен
    if (!req.file) {
      console.log("❌ Ошибка: файл не загружен");
      return res.status(400).json({
        success: false,
        error: "Файл не загружен. Выберите файл."
      });
    }

    const filePath = req.file.path;
    console.log("📁 Путь к файлу:", filePath);
    
    // Пытаемся прочитать Excel файл
    console.log("📖 Чтение файла...");
    let workbook;
    try {
      workbook = xlsx.readFile(filePath);
    } catch (readError) {
      console.log("❌ Ошибка чтения файла:", readError.message);
      throw new Error(`Не удалось прочитать файл. Убедитесь, что это правильный Excel файл. Ошибка: ${readError.message}`);
    }
    
    console.log("✅ Файл прочитан успешно");
    console.log("📊 Листы в файле:", workbook.SheetNames);
    
    // Берем первый лист
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Конвертируем в массив данных
    console.log("🔄 Конвертация в JSON...");
    const data = xlsx.utils.sheet_to_json(worksheet, { 
      header: 1,          // Получаем массив массивов
      defval: "",         // Значение по умолчанию для пустых ячеек
      blankrows: false    // Не включать полностью пустые строки
    });
    
    console.log("✅ Получено строк:", data.length);
    
    // Фильтруем пустые строки
    const filteredData = data.filter(row => {
      if (!Array.isArray(row)) return false;
      return row.some(cell => {
        if (cell === null || cell === undefined) return false;
        if (typeof cell === "string" && cell.trim() === "") return false;
        return true;
      });
    });
    
    console.log("✅ После фильтрации строк:", filteredData.length);
    
    // Считаем количество столбцов
    const maxColumns = filteredData.length > 0 
      ? Math.max(...filteredData.map(row => row.length))
      : 0;
    
    // Формируем результат
    const result = {
      success: true,
      filename: req.file.originalname,
      sheetName: sheetName,
      rows: filteredData.length,
      columns: maxColumns,
      data: filteredData,
      message: "Файл успешно обработан"
    };
    
    console.log("📊 Результат:", {
      файл: result.filename,
      строк: result.rows,
      столбцов: result.columns
    });
    
    // Удаляем временный файл
    fs.unlinkSync(filePath);
    console.log("🗑️ Временный файл удален");
    
    // Отправляем результат
    res.json(result);
    
  } catch (error) {
    console.error("❌ КРИТИЧЕСКАЯ ОШИБКА:", error.message);
    
    // Удаляем файл при ошибке
    if (req.file && fs.existsSync(req.file.path)) {
      try {
        fs.unlinkSync(req.file.path);
        console.log("🗑️ Файл удален после ошибки");
      } catch (e) {
        console.error("Ошибка при удалении файла:", e.message);
      }
    }
    
    // Отправляем ошибку клиенту
    res.status(500).json({
      success: false,
      error: "Ошибка обработки файла",
      message: error.message,
      hint: "Убедитесь, что файл: 1) Имеет расширение .xls, .xlsx или .csv 2) Не поврежден 3) Создан в Microsoft Excel"
    });
  }
});

// ===== FRONTEND =====

// Главная страница с формой загрузки
app.get("/", (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Excel Parser - Парсинг таблиц</title>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: Arial, sans-serif;
            }
            
            body {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            
            .container {
                width: 100%;
                max-width: 800px;
                background: white;
                border-radius: 15px;
                padding: 40px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            }
            
            h1 {
                color: #333;
                text-align: center;
                margin-bottom: 10px;
                font-size: 32px;
            }
            
            .subtitle {
                text-align: center;
                color: #666;
                margin-bottom: 30px;
                font-size: 16px;
            }
            
            .upload-area {
                border: 3px dashed #667eea;
                border-radius: 10px;
                padding: 60px 20px;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s;
                margin-bottom: 20px;
                position: relative;
            }
            
            .upload-area:hover {
                background: #f8f9ff;
                border-color: #764ba2;
            }
            
            .upload-icon {
                font-size: 64px;
                color: #667eea;
                margin-bottom: 20px;
            }
            
            .upload-text {
                font-size: 20px;
                color: #333;
                margin-bottom: 10px;
            }
            
            .upload-hint {
                color: #666;
                font-size: 14px;
                margin-bottom: 5px;
            }
            
            #fileInput {
                display: none;
            }
            
            .file-info {
                background: #f8f9ff;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
                border-left: 4px solid #667eea;
                display: none;
            }
            
            .button {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                border: none;
                padding: 15px 40px;
                border-radius: 8px;
                font-size: 18px;
                cursor: pointer;
                display: block;
                width: 100%;
                margin: 20px 0;
                transition: transform 0.3s;
            }
            
            .button:hover {
                transform: translateY(-2px);
            }
            
            .button:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                transform: none;
            }
            
            .loading {
                display: none;
                text-align: center;
                padding: 20px;
            }
            
            .spinner {
                border: 4px solid #f3f3f3;
                border-top: 4px solid #667eea;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin: 0 auto 15px;
            }
            
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            
            .result-container {
                margin-top: 30px;
                padding: 20px;
                background: #f8f9ff;
                border-radius: 10px;
                display: none;
            }
            
            .error {
                background: #ffebee;
                color: #c62828;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
                display: none;
            }
            
            .success {
                background: #e8f5e9;
                color: #2e7d32;
                padding: 15px;
                border-radius: 8px;
                margin: 20px 0;
            }
            
            table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
                background: white;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            
            th, td {
                border: 1px solid #e1e5f1;
                padding: 12px;
                text-align: left;
            }
            
            th {
                background: #f2f4ff;
                font-weight: bold;
                color: #333;
            }
            
            pre {
                background: #2d3748;
                color: #e2e8f0;
                padding: 20px;
                border-radius: 8px;
                overflow: auto;
                max-height: 400px;
                font-family: 'Courier New', monospace;
                font-size: 14px;
            }
            
            .stats {
                display: flex;
                gap: 20px;
                margin-bottom: 20px;
            }
            
            .stat-item {
                flex: 1;
                background: white;
                padding: 15px;
                border-radius: 8px;
                text-align: center;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }
            
            .stat-value {
                font-size: 24px;
                font-weight: bold;
                color: #667eea;
            }
            
            .stat-label {
                font-size: 14px;
                color: #666;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Excel Parser</h1>
            <p class="subtitle">Загрузите Excel таблицу и получите JSON структуру</p>
            
            <div class="upload-area" id="dropArea">
                <div class="upload-icon">📁</div>
                <div class="upload-text">Нажмите для выбора файла</div>
                <div class="upload-hint">или перетащите файл сюда</div>
                <div class="upload-hint">Поддерживаемые форматы: .xls, .xlsx, .csv</div>
                <div class="upload-hint">Максимальный размер: 5 МБ</div>
            </div>
            
            <input type="file" id="fileInput" accept=".xls,.xlsx,.csv">
            
            <div class="file-info" id="fileInfo">
                <div><strong>Выбран файл:</strong> <span id="fileName"></span></div>
                <div><strong>Размер:</strong> <span id="fileSize"></span></div>
            </div>
            
            <button class="button" id="uploadBtn" onclick="uploadFile()" disabled>🚀 Распознать таблицу</button>
            
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p>Обработка файла...</p>
            </div>
            
            <div class="error" id="error"></div>
            
            <div class="result-container" id="resultContainer">
                <div class="success" id="successMessage">✅ Файл успешно обработан!</div>
                
                <div class="stats" id="stats">
                    <div class="stat-item">
                        <div class="stat-value" id="statRows">0</div>
                        <div class="stat-label">Строк</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="statCols">0</div>
                        <div class="stat-label">Столбцов</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="statFileName">-</div>
                        <div class="stat-label">Имя файла</div>
                    </div>
                </div>
                
                <div>
                    <h3>📋 Таблица:</h3>
                    <div id="tableContainer"></div>
                </div>
                
                <div style="margin-top: 30px;">
                    <h3>📄 JSON результат:</h3>
                    <pre id="jsonOutput"></pre>
                    <button class="button" onclick="copyJSON()" style="margin-top: 10px;">📋 Копировать JSON</button>
                </div>
            </div>
        </div>

        <script>
            // Элементы DOM
            const fileInput = document.getElementById('fileInput');
            const dropArea = document.getElementById('dropArea');
            const fileInfo = document.getElementById('fileInfo');
            const fileName = document.getElementById('fileName');
            const fileSize = document.getElementById('fileSize');
            const uploadBtn = document.getElementById('uploadBtn');
            const loading = document.getElementById('loading');
            const errorDiv = document.getElementById('error');
            const resultContainer = document.getElementById('resultContainer');
            const successMessage = document.getElementById('successMessage');
            const stats = document.getElementById('stats');
            const statRows = document.getElementById('statRows');
            const statCols = document.getElementById('statCols');
            const statFileName = document.getElementById('statFileName');
            const tableContainer = document.getElementById('tableContainer');
            const jsonOutput = document.getElementById('jsonOutput');
            
            let currentResult = null;
            
            // Инициализация
            document.addEventListener('DOMContentLoaded', () => {
                console.log('Excel Parser загружен');
                
                // Клик по области загрузки
                dropArea.addEventListener('click', () => {
                    fileInput.click();
                });
                
                // Drag & Drop
                dropArea.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    dropArea.style.background = '#f0f4ff';
                });
                
                dropArea.addEventListener('dragleave', () => {
                    dropArea.style.background = '';
                });
                
                dropArea.addEventListener('drop', (e) => {
                    e.preventDefault();
                    dropArea.style.background = '';
                    if (e.dataTransfer.files.length) {
                        handleFile(e.dataTransfer.files[0]);
                    }
                });
                
                // Выбор файла через input
                fileInput.addEventListener('change', (e) => {
                    if (e.target.files.length) {
                        handleFile(e.target.files[0]);
                    }
                });
            });
            
            function handleFile(file) {
                // Проверка размера (5 МБ)
                if (file.size > 5 * 1024 * 1024) {
                    showError('Файл слишком большой. Максимальный размер: 5 МБ');
                    return;
                }
                
                // Проверка расширения
                const ext = file.name.split('.').pop().toLowerCase();
                if (!['xls', 'xlsx', 'csv'].includes(ext)) {
                    showError('Неподдерживаемый формат. Используйте: .xls, .xlsx, .csv');
                    return;
                }
                
                // Показываем информацию о файле
                fileName.textContent = file.name;
                fileSize.textContent = formatFileSize(file.size);
                fileInfo.style.display = 'block';
                uploadBtn.disabled = false;
                
                // Скрываем предыдущие результаты и ошибки
                resultContainer.style.display = 'none';
                hideError();
            }
            
            async function uploadFile() {
                if (!fileInput.files[0]) {
                    showError('Выберите файл для загрузки');
                    return;
                }
                
                const formData = new FormData();
                formData.append('file', fileInput.files[0]);
                
                // Показываем загрузку
                loading.style.display = 'block';
                uploadBtn.disabled = true;
                hideError();
                
                try {
                    console.log('Отправка файла на сервер...');
                    
                    const response = await fetch('/api/recognize-table', {
                        method: 'POST',
                        body: formData
                    });
                    
                    console.log('Ответ получен, статус:', response.status);
                    
                    // Проверяем, что ответ - JSON
                    const contentType = response.headers.get('content-type');
                    if (!contentType || !contentType.includes('application/json')) {
                        const text = await response.text();
                        console.error('Не JSON ответ:', text.substring(0, 200));
                        throw new Error('Сервер вернул не JSON ответ. Возможно, ошибка в API.');
                    }
                    
                    const result = await response.json();
                    console.log('Результат:', result);
                    
                    if (!response.ok || !result.success) {
                        throw new Error(result.error || result.message || 'Ошибка сервера');
                    }
                    
                    // Показываем результат
                    showResult(result);
                    
                } catch (error) {
                    console.error('Ошибка загрузки:', error);
                    showError(error.message || 'Неизвестная ошибка');
                } finally {
                    loading.style.display = 'none';
                    uploadBtn.disabled = false;
                }
            }
            
            function showResult(data) {
                currentResult = data;
                
                // Обновляем статистику
                statRows.textContent = data.rows;
                statCols.textContent = data.columns;
                statFileName.textContent = data.filename;
                
                // Показываем таблицу
                renderTable(data.data);
                
                // Показываем JSON
                jsonOutput.textContent = JSON.stringify(data, null, 2);
                
                // Показываем контейнер с результатами
                resultContainer.style.display = 'block';
                successMessage.textContent = \`✅ Файл "\${data.filename}" успешно обработан!\`;
                
                // Прокручиваем к результатам
                resultContainer.scrollIntoView({ behavior: 'smooth' });
            }
            
            function renderTable(data) {
                if (!data || data.length === 0) {
                    tableContainer.innerHTML = '<p>Таблица пуста</p>';
                    return;
                }
                
                // Определяем максимальное количество столбцов
                const maxCols = Math.max(...data.map(row => row.length));
                
                let html = '<table><thead><tr>';
                
                // Заголовки столбцов (номера)
                for (let i = 0; i < maxCols; i++) {
                    html += \`<th>Col \${i + 1}</th>\`;
                }
                html += '</tr></thead><tbody>';
                
                // Данные
                data.forEach((row, rowIndex) => {
                    html += '<tr>';
                    for (let i = 0; i < maxCols; i++) {
                        const cell = row[i] !== undefined ? row[i] : '';
                        // Первую строку можно выделить как заголовок
                        if (rowIndex === 0 && i < row.length && row[i]) {
                            html += \`<th>\${escapeHtml(String(cell))}</th>\`;
                        } else {
                            html += \`<td>\${escapeHtml(String(cell))}</td>\`;
                        }
                    }
                    html += '</tr>';
                });
                
                html += '</tbody></table>';
                tableContainer.innerHTML = html;
            }
            
            function copyJSON() {
                if (!currentResult) return;
                
                const jsonString = JSON.stringify(currentResult, null, 2);
                navigator.clipboard.writeText(jsonString)
                    .then(() => {
                        alert('✅ JSON скопирован в буфер обмена!');
                    })
                    .catch(() => {
                        alert('❌ Не удалось скопировать JSON');
                    });
            }
            
            function showError(message) {
                errorDiv.textContent = message;
                errorDiv.style.display = 'block';
                
                // Автоскрытие через 5 секунд
                setTimeout(() => {
                    hideError();
                }, 5000);
            }
            
            function hideError() {
                errorDiv.style.display = 'none';
            }
            
            function formatFileSize(bytes) {
                if (bytes < 1024) return bytes + ' Б';
                if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' КБ';
                return (bytes / (1024 * 1024)).toFixed(1) + ' МБ';
            }
            
            function escapeHtml(text) {
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
            
            // Тест API при загрузке
            window.addEventListener('load', async () => {
                try {
                    const response = await fetch('/api/health');
                    if (response.ok) {
                        console.log('✅ API работает корректно');
                    }
                } catch (error) {
                    console.warn('⚠️ Не удалось проверить API:', error.message);
                }
            });
        </script>
    </body>
    </html>
  `);
});

// Запуск сервера
app.listen(PORT, () => {
  console.log("=".repeat(60));
  console.log("🚀 EXCEL PARSER ЗАПУЩЕН!");
  console.log("=".repeat(60));
  console.log(`📍 Главная страница: http://localhost:${PORT}`);
  console.log(`🔧 Проверка API:     http://localhost:${PORT}/api/health`);
  console.log(`📤 API загрузки:     POST http://localhost:${PORT}/api/recognize-table`);
  console.log("=".repeat(60));
  console.log("📁 Папка загрузок:", path.join(__dirname, uploadDir));
  console.log("💡 Для остановки: Ctrl+C");
  console.log("=".repeat(60));
});
